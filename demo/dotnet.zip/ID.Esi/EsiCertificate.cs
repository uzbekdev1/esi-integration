﻿namespace ID.Esi
{
    public class EsiCertificate
    { 

        public string CN { get; set; }

        public string O { get; set; }

        public string T { get; set; }

        public string TIN { get; set; }

        public string UID { get; set; }

        public string Alias { get; set; }

        public string Disk { get; set; }

        public string Name { get; set; }

        public string Path { get; set; }

        public string SerialNumber { get; set; }

        public string Type { get; set; }

        public string ValidFrom { get; set; }

        public string ValidTo { get; set; } 

    }
}