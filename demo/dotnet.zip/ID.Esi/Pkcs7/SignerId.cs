﻿namespace ID.Esi.Pkcs7
{
    public class SignerId
    {
        
        public string issuer { get; set; }
        
        public string subjectSerialNumber { get; set; }

    }
}