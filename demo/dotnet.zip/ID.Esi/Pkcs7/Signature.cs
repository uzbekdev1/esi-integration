﻿namespace ID.Esi.Pkcs7
{
    public class Signature
    {
        
        public string signAlgName { get; set; }
        
        public string signature { get; set; }

    }
}