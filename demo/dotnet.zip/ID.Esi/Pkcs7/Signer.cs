﻿using System.Collections.Generic;

namespace ID.Esi.Pkcs7
{
    public class Signer
    {
        
        public SignerId SignerId { get; set; }
        
        public string SigningTime { get; set; }
        
        public string Signature { get; set; }
        
        public string Digest { get; set; }
        
        public List<Certificate> Certificate { get; set; }
        
        public string OcspResponse { get; set; }
        
        public bool Verified { get; set; }
        
        public bool CertificateVerified { get; set; }
        
        public List<object> PolicyIdentifiers { get; set; }
        
        public bool CertificateValidAtSigningTime { get; set; }

        public string Exception { get; set; }

        public string StatusUpdatedAt { get; set; }
        
        public string StatusNextUpdateAt { get; set; }

        public TrustedCertificate TrustedCertificate { get; set; }

        public bool TotallyVerified => Verified && CertificateVerified && CertificateValidAtSigningTime;

    }
}