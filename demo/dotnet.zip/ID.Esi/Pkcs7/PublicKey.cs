﻿namespace ID.Esi.Pkcs7
{
    public class PublicKey
    {
        
        public string keyAlgName { get; set; }
        
        public string publicKey { get; set; }

    }
}