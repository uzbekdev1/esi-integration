﻿using System.Collections.Generic;

namespace ID.Esi.Pkcs7
{
    public class Pkcs7Info
    {
        
        public List<Signer> Signers { get; set; }
        
        public string DocumentBase64 { get; set; }

    }
}