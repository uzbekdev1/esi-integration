﻿namespace ID.Esi.Pkcs7
{
    public class PkcsVerifyResult
    {

        public Pkcs7Info Pkcs7Info { get; set; }
        
        public bool Success { get; set; }

    }
}