﻿namespace ID.Esi.Pkcs7
{
    public class Certificate
    {
        
        public string serialNumber { get; set; }
        
        public string subjectName { get; set; }
        
        public string validFrom { get; set; }
        
        public string validTo { get; set; }
        
        public string issuerName { get; set; }
        
        public PublicKey publicKey { get; set; }
        
        public Signature signature { get; set; }

    }
}