﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;
using ID.Esi.Pkcs7;
using ServiceReference1;

namespace ID.Esi
{
    public class EsiService
    {

        private static async Task<PkcsVerifyResult> Verifying(string data)
        {
            using var client = new Pkcs7Client();
            var result = await client.verifyPkcs7Async(data);

            return JsonConvert.DeserializeObject<PkcsVerifyResult>(result.Body.@return);
        }

        private static bool IsVerified(PkcsVerifyResult result, string serial, string tin)
        {
            if (!result.Success)
            {
                return false;
            }

            var signer = result.Pkcs7Info.Signers.FirstOrDefault();

            if (signer == null)
            {
                return false;
            }

            var cert = signer.Certificate.FirstOrDefault();
            
            if (cert.serialNumber.ToLower() != serial.ToLower() ||
                !cert.subjectName.Contains($"={tin}"))
            {
                return false;
            }

            return signer.Verified && signer.CertificateVerified && signer.CertificateValidAtSigningTime;
        }

        public async Task<EsiValidation> Validate(string signature, string signed, string certificate)
        {
            var model = new EsiValidation();

            try
            {
                if (string.IsNullOrWhiteSpace(signature) || string.IsNullOrWhiteSpace(signed))
                {
                    model.Error = "Ключи не найдены. Пожалуйста, обновите страницу.";

                    return model;
                }

                var cert = JsonConvert.DeserializeObject<EsiCertificate>(certificate);

                if (cert == null)
                {
                    model.Error = "ЭЦП не совпадает с данными. Обратитесь к администратору.";

                    return model;
                }

                var result = await Verifying(signature);

                if (!IsVerified(result, cert.SerialNumber, cert.TIN))
                {
                    model.Error = "ЭЦП устарел или удален. Обратитесь в Государственный Налоговый Комитет!";

                    return model;
                }

                model.Signed = result.Pkcs7Info.DocumentBase64;
                model.IsSuccess = true;

            }
            catch (Exception e)
            {
                model.Error = e.InnerException?.Message ?? e.Message;
            }

            return model;
        }

    }
}