﻿namespace ID.Esi
{
    public class EsiValidation
    {

        public bool IsSuccess { get; set; }

        public string Error { get; set; }

        public string Signed { get; set; }

    }
}
